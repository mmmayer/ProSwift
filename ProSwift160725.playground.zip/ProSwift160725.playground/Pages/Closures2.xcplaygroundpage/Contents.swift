//: [Previous](@previous)

import Foundation

let names = ["Michael Jackson", "Taylor Swift", "Michael Caine", "Adele Adkins", "Michael Jordan"]

var result = names.filter({ (name: String) -> Bool in
	if name.hasPrefix("Michael") {
		return true
	} else {
		return false;
	}
})
print(result.count)


result = names.filter({ name in
	if name.hasPrefix("Michael") {
		return true
	} else {
		return false;
	}
})
print(result.count)


result = names.filter({ name in
	return name.hasPrefix("Michael")
})
print(result.count)


result = names.filter { name in
	return name.hasPrefix("Michael")
}
print(result.count)


result = names.filter { name in
	name.hasPrefix("Michael")
}
print(result.count)


result = names.filter { $0.hasPrefix("Michael") }
print(result.count)



//: [Next](@next)
