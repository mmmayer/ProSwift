//: [Previous](@previous)

import Foundation

// Two scary examples of breaking swift with operator overloads
// 1) broke "==" by overloading it so that it always returned false
// 2) broke "* / + -" by changing the precedence of the "*" operator 
//    so that it was less than the additive "+ -" operators

// Preconditions for overloading or creating a new operator: Obvious & unsurprising
// Reasons: must be compelling


// precedence - relative
let a = 10 * 5 + 2
let b = (10 * 5) + 2
let c = 10 * (5 + 2)

// associativity
let d = 10 - 5 - 1
let e = (10 - 5) - 1
let f = 10 - (5 - 1)


// default predcedence and associativity - 100 and none
infix operator ** {}

func **(lhs: Double, rhs: Double) -> Double {
	return pow(lhs, rhs)
}
3**2
// Dot Product
infix operator •{
associativity left
precedence 150
}

func •(lhs: [Int], rhs:[Int]) -> Int? {
	guard lhs.count == rhs.count else { return nil }
	var result = 0
	
	for i in 0..<lhs.count {
		result += lhs[i] * rhs[i]
	}
	return result
}

[1,2,-5] • [5, -2, 3]
[1, 3, -5] • [4, -2, -1]
[1, 3, -5] • [4, -2, -1, 0, 0]


infix operator ...{
    associativity left
    precedence 135
}

func ...(lhs: Range<Int>, rhs:Int) -> [Int] {
	guard let maximum = lhs.last else { return Array(lhs) }
	
	let downwards = (rhs ..< maximum).reverse()
	return Array(lhs) + downwards
}

let range = 1...10...1

//: [Next](@next)
