//: [Previous](@previous)

import Foundation

// ~=

(1...100).contains(42)
1...100 ~= 42
1...100 ~= 142


extension Array {
	subscript(safe idx: Int) -> Element? {
		return 0..<endIndex ~= idx ? self[idx] : nil
	}
}

let a = [1, 2, 3, 4, 5, 6]

a[safe:4]
a[safe:2]
a[safe:-1]
a[safe:7]

a[safe:7]

//: [Next](@next)
