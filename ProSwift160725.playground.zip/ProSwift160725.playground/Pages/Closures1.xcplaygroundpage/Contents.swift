//: [Previous](@previous)

import Foundation
import XCPlayground

XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

var greetPerson = {
	print("Hello there!")
}
greetPerson()

let greetCopy = greetPerson
greetCopy()

func runSomeClosure(closure: () -> Void) {
	closure()
}
runSomeClosure(greetPerson)

//greetPerson = { (name: String) in
//	print("hello, \(name)!")
//}
//greetPerson("Taylor")

var greetPerson2 = { (name: String) in
	print("Hello, \(name)!")
}
greetPerson2("Taylor")


//var greetPerson3 = { (name: String) [unowned self] in
//	print("hello, \(name)!")
//}
//greetPerson3("Taylor")


func runSomeClosure(closure: (String) -> Void) {
	closure("Taylor")
}
runSomeClosure(greetPerson2)  // overloaded - try greetPerson2


func produceFunction() -> (name: String) -> Void {
	var counter = 0
	runAfterDelay(3) {
		print("The counter is: \(counter)")
	}
	return { (name: String) in
		counter += 1
		print("Hello, \(name)!")
	}
}

let printName = produceFunction()
printName(name: "Debbie")
printName(name: "Debbie")
printName(name: "Debbie")


//: [Next](@next)
