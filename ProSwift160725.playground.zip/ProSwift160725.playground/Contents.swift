import Cocoa

print(1, 2, 3, 4, 5, 6)

func addNumbers(numbers: [Int]) -> Int {
	var total = 0
	
	for number in numbers {
		total += number
	}
	
	return total
}
addNumbers([1, 2, 3, 4, 5])



func addNumbers2(numbers: Int...) -> Int {
	var total = 0
	
	for number in numbers {
		total += number
	}
	
	return total
}
addNumbers2(1, 2, 3, 4, 5)


enum Cats {
	case Siamese
	case manx
	case persian
	case tonkinese
	case house
	case tom
}

// How does print do this?
print(1, "LA", 3, 4.6, 5, Cats.tom)
print(1, "LA", 3, 4.6, 5, Cats.tom, separator: ", ", terminator: "!")