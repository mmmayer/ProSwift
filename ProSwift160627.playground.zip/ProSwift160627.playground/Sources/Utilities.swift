import Foundation

// Need to make everything in Souurces folder public if it is to be seen in Playgrounds!
public extension Array {
	public mutating func popFirst() -> Element? {
		if !self.isEmpty {
			return self.removeFirst()
		}
		return nil
	}
}

