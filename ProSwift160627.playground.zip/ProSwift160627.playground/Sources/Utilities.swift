import Foundation

// Need to make everything in Souurces folder public if it is to be seen in Playgrounds!
public extension Array {
	public mutating func popFirst() -> Element? {
		guard !self.isEmpty else { return nil }
		return self.removeFirst()
	}
}

