//: [Previous](@previous)
//: # **Enums**
import Foundation

enum Color1 {
	case Unknown
	case Blue
	case Green
	case Pink
	case Purple
	case Red
}

enum Color2 {
	case Unknown, Blue, Green, Pink, Purple, Red
}

enum Color3 : Int {
	case Unknown = 5, Blue = -3, Green, Pink, Purple, Red
}

let a = Color3.Red.rawValue

enum Color4: String {
	case Unknown, Blue, Green, Pink, Purple, Red
}
let favorite = Color4.Pink.rawValue


struct Toy {
	let name: String
	let color: Color3
}
let barbie = Toy(name: "Barbie", color: .Pink)

// Stored properties must be static
// Computed properties okay
// functions okay



//: [Next](@next)
