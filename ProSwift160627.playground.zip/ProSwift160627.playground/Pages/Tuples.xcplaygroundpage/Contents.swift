//: [Previous](@previous)
//: # **Tuples**
import Foundation

var singer = (first: "Taylor", last: "Swift")
print(singer.last)
print(singer.0)


var singer2 = (first: "Taylor", last: "Swift", sing: { (lyrics: String) in
	print("\(lyrics)")
})
singer2.sing("LA LA LA  LA LA")




func fetchWeather() -> (type: String, cloudCover: Int, high: Int,
	low: Int) {
		return ("Sunny", 50, 32, 26)
}

let weather = fetchWeather()
print(weather.type)
print(weather.high)

let (weather2, cloud, highTemp, lowTemp) = fetchWeather()
print(weather2)
print(highTemp)



let optionalElements1: (String?, String?) = ("Taylor", nil)
let optionalElements2: (String?, String?) = (nil, "Swift")
let optionalElements3: (String?, String?) = (nil, nil)

let optionalTuple1: (String, String)? = ("Taylor", "Swift")
let optionalTuple2: (String, String)? = nil

let optionalBoth1: (String?, String?)? = (nil, "Swift")
let optionalBoth2: (String?, String?)? = (nil, nil)
let optionalBoth3: (String?, String?)? = nil



let singer3 = (first: "Taylor", last: "Swift")
let person = (first: "Justin", last: "Bieber")
singer == person

let bird = (name: "Taylor", breed: "Swift")
singer3 == bird

// Can compare up to a 6 n-ary tuple - a tuple with 6 members



let father = (first: "Scott", last: "Swift")
let mother = (first: "Andrea", last: "Finlay")

func marryTaylorsParents(man man: (first: String, last: String),
	woman: (first: String, last: String)) -> (husband: (first: String,
	last: String), wife: (first: String, last: String)) {
		return (man, (woman.first, man.last))
}

typealias Name = (first: String, last: String)

func marryTaylorsParents2(man man: Name, woman: Name) -> (husband: Name, wife: Name) {
		return (man, (woman.first, man.last))
}

//: [Next](@next)
