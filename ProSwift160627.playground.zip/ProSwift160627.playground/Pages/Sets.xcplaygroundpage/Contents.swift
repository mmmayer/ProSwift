//: [Previous](@previous)
//: # **Sets**
import Foundation

// Sets: just like arrays, only unordered and every member unique.  Members must be hashable.
// determining membership is O(1) versus Array which is O(N)

var set1 = Set<Int>([1, 2, 3, 4, 5])
var set2 = Set<Int>(0...100)
set2.insert(101)  // insert instead of append
// lots of the same functions from Array operate on sets (and return arrays such as sort, map and filter)



// Set Operations
let spaceships1 = Set(["Serenity", "Nostromo", "Enterprise"])
let spaceships2 = Set(["Voyager", "Serenity", "Executor"])
let spaceships3 = Set(["Galactica", "Sulaco", "Minbari"])

let union = spaceships1.union(spaceships2)
let intersection = spaceships1.intersect(spaceships2)
let difference = spaceships1.exclusiveOr(spaceships2)

let allSpaceships = spaceships1.union(spaceships2).union(spaceships3)



spaceships1.isSubsetOf(union) // true
spaceships1.isSubsetOf(spaceships1) // true
spaceships1.isSubsetOf(spaceships2) // false
spaceships1.isStrictSubsetOf(union) // true
spaceships1.isStrictSubsetOf(spaceships1) // false
union.isSupersetOf(spaceships2) // true
union.isSupersetOf(spaceships3) // false
union.isStrictSupersetOf(spaceships1) // true
spaceships1.isDisjointWith(spaceships2) // false



// NSCountedSet in Foundation is a set that keeps track of how many times a member was added.  Removing a member doesn't decrement the count, it just removes the member.  Will be called CountedSet in Swift3
//: [Next](@next)
