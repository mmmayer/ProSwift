//: # **Initializers**
import Cocoa

let bar1 = Array<Int>(count: 8, repeatedValue: 1)
let bar2 = [Int](count: 8, repeatedValue: 1)
let bar3 = Array(count: 8, repeatedValue: "LA")

let foo0: [String]
let foo1 = [String]()
let foo2 = ["DO", "RE", "MI", "FA", "SO", "LA", "TI"]
let foo3 = Array(count: 8, repeatedValue: "LA")
// My attempt to avoid using angle brackets < > if at all possible.



let heading = "This is a heading"
let underline = String(count: heading.characters.count,
                       repeatedValue: Character("="))
let underline2 = [String](count: heading.characters.count,
                           repeatedValue: "=")



let numStr1 = 123.description   // A
let numStr2 = "\(123)"          //  B
let numStr3 = String(123)       // C



let int0 = Int("1989")
if let int1 = Int("1989") {
	print(int1)
}
let int2 = Int("1989") ?? 0




let str1 = String(28, radix: 16)
let str2 = String(28, radix: 16, uppercase: true)

let int3 = Int("FF", radix: 16)  // Optional
let int4 = Int("FF", radix: 16) ?? 0



// de duping
let scores = [5, 3, 6, 1, 3, 5, 3, 9]
let scoresSet = Set(scores)  // notice the order changes
let uniqueScores = Array(scoresSet)

extension Array where Element : Comparable  {
	func dedupe() -> [Element] {
		var newArray = [Element]()
		for elem in self {
			if !newArray.contains(elem) {
				newArray.append(elem)
			}
		}
		return newArray
	}
}

let uniqueScores2 = scores.dedupe()  // order did not change, Array elements did have to be hashable, O(N-squared)



var dictionary = Dictionary<String, String>(minimumCapacity: 100)


//: [Next](@next)
