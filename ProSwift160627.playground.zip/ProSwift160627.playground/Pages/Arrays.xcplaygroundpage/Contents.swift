//: [Previous](@previous)
//: # **Arrays**
import Foundation

var names = ["Taylor", "Timothy", "Tyler", "Thomas", "Tobias",
             "Tabitha"]

// sorting requires that the elements adhere to the Comparable protocol
names.sortInPlace()  // default is ascending
names



let result1 = names.sort {$0 > $1}  // descending sort
result1

// sortInPlace() is renamed sorted() in Swift 3



let lowest = names.minElement()
let highest = names.maxElement()

let mini = names.reduce(names[0]) { $0 < $1 ? $0 : $1 }
mini



// We need this for the Equatable
func ==(lhs: Dog, rhs: Dog) -> Bool {
	return lhs.age == rhs.age
}

// We need this for Comparable
func <(lhs: Dog, rhs: Dog) -> Bool {
	return lhs.breed < rhs.breed
}

struct Dog: Comparable {
	var breed: String
	var age: Int
}

let puppy = Dog(breed: "Poodle", age: 5)
let rusty = Dog(breed: "Labrador", age: 2)
let rover = Dog(breed: "Corgi", age: 11)
var dogs = [puppy, rusty, rover]

let beethoven = Dog(breed: "St Bernard", age: 8)
dogs += [beethoven]

dogs.append(beethoven)



dogs.isEmpty // is faster than
dogs.count == 0



var cats = [Int]()
cats.reserveCapacity(10)  // reserving space in advance can save time



let pup1 = dogs.removeLast() // removes and then returns the last Element.  Crashes if array is empty
let pup2 = dogs.popLast()  // removes and then returns the last Element?.  Returns nil is array is empty

let pup3 = dogs.removeFirst() // reremoves and then returns the last Element.  Crashes if array is empty
let pup4 = dogs.popFirst() // doesn't exist but we can write it - look in sources

// ContiguousArray is faster than Array
//: [Next](@next)

