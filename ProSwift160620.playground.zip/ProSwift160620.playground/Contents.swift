import Cocoa

class Singer {
	let name: String
	lazy var reversedName: String = self.getReversedName()

	init(name: String) {
		self.name = name
	}
	
	private func getReversedName() -> String {
		return "\(self.name.uppercaseString) backwards is \(String(self.name.uppercaseString.characters.reverse()))!"
	}
}


let taylor = Singer(name: "Taylor Swift")
print(taylor.reversedName)



var arr = [1, 2, 3, 4, 5, 6]

// if lazy, the map will only operate on elements that get accessed.
// However, the result is not saved.
var arr2 = arr.lazy.map { $0 * 3 }
arr2[2]
arr2[4]



class MusicPlayer {
	init() {
		print("Ready to play songs!")
	}
}

class Singer2 {
	static let musicPlayer = MusicPlayer()
	init() {
		print("Creating a new singer")
	}
}
let taylor2 = Singer2()
Singer2.musicPlayer


let data = ("one", "two", "three")
let (one, two, three) = data

var a = 5
var b = 10
(a, b) = (b, a)
a

/*
printing: if userRequestedPrint() {
	guard documentSaved() else { break printing }
	guard userAuthenticated() else{  break printing }
	guard connectToNetwork() else { break printing }
	guard uploadDocument("work.doc") else { break printing }
	guard printDocument() else { break printing }
	
	print("Printed successfully!")
}
*/

enum R {
	enum Storyboards: String {
		case Main, Detail, Upgrade, Share, Help
	}
	
	enum Images: String {
		case Welcome, Home, About, Button
	}
}

R.Storyboards.Share


struct Deck {
	struct Card {
		enum Suit {
			case Spades, Hearts, Diamonds, Clubs
		}
		
		var rank: Int
		var suit: Suit
	}
	
	var cards = [Card]()
}

Deck.Card.Suit.Hearts


struct Point {
	let x: Double
	let y: Double
}

enum DistanceTechnique {
	case Euclidean
	case EuclideanSquared
	case RectiLinear
}

func createDistanceAlgorithm(technique technique: DistanceTechnique) -> (start: Point, end: Point) -> Double {
	func calculateEuclideanDistanceSquared(start start: Point, end: Point) -> Double {
		let deltaX = start.x - end.x
		let deltaY = start.y - end.y
		
		return deltaX * deltaX + deltaY * deltaY
	}
	
	func calculateEuclideanDistance(start start: Point, end: Point) -> Double {
		return sqrt(calculateEuclideanDistanceSquared(start: start, end: end))
	}
	
	func calculateRectiLinearDistance(start start: Point, end: Point) -> Double {
		return abs(start.x - end.x) + abs(start.y - end.y)
	}
	
	switch technique {
	case .Euclidean:
		return calculateEuclideanDistance
	case .EuclideanSquared:
		return calculateEuclideanDistanceSquared
	case .RectiLinear:
		return calculateRectiLinearDistance
	}
}

let calcDistance = createDistanceAlgorithm(technique: .RectiLinear)

calcDistance(start: Point(x: 10, y:10),  end: Point(x:20, y:20))


/** 
* Bulleted Lists
````
    Code Block
````
Inline Code `return true` monospaced

*Italics*

**Bold**
### Headings

Others: Horizontal Rules,
Images,
Link Reference,
Links,
Numbered Lists
1. Number One
4. Number Two

### Callouts:
- Attention: Adds an Attention callout
- Author: Adds an Author callout
- Authors: Adds an Authors callout for multiple authors
- Bug: Adds a Bug callout
- Complexity: O(N) Adds a Complexity callout
- Copyright: Adds a Copyright callout
- Date: Today Adds a Date callout
- Example: Adds an Example callout
- Experiment: Adds an Experiment callout
- Important: Adds an Important callout
- Invariant - Adds an Invariant callout
- Note: Adds a Note callout
- Parameter num: Adds a Parameter to the parameters section of Quick Help
- Parameters: Adds multiple Parameters to the parameters section of Quick Help
- Postcondition: Adds a Postcondition callout
- Precondition: Adds a Precondition callout
- Remark: Adds a Remark callout
- Returns: Always returns true.  Adds the Returns section to Quick Help
- Requires: Adds a Requires callout
- See Also: Adds a See Also callout
- Since: Adds a Since callout
- Throws: Adds the Throws section to Quick Help
- ToDo: Adds a To Do callout
- Version: Adds a Version callout
- Warning: Adds a Warning callout

*/
func doesEverything(num:Int, str: String) -> Bool {
	return true
}