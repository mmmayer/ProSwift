import Foundation
//
//class Target {
//	var location = ""
//}

struct Target {
	var location = ""
}

struct Rebel {
	var target = Target()
}

var luke = Rebel()
var wedge = Rebel()

// create a target
var target = Target()

// set its location to be the Death Star
target.location = "Death Star"

// tell Luke to attack the Death Star
luke.target = target
wedge.target = target

// oh no – Wedge is hit! We need to
// tell him to fly home
target.location = "Rebel Base"
wedge.target = target

// report back to base
print(wedge.target.location)

// Attack your target
print(luke.target.location)




var a = [1, 2, 3]
var b = a
b.append(4)

 a


//: [Next](@next)
