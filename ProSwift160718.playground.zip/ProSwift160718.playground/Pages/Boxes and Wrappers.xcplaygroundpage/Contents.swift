//: [Previous](@previous)

import Foundation


struct Person {
	var name: String
	var age: Int
	var favoriteIceCream: String
}

var taylor = Person(name: "Taylor Swift", age: 26, favoriteIceCream:
	"Chocolate")


final class Box<T> {
	var value: T
	init(value: T) {
		self.value = value
	}
}


final class TestContainer {
	var box: Box<Person>!
}

let box = Box(value:taylor)

let container1 = TestContainer()
let container2 = TestContainer()
container1.box = box
container2.box = box

print(container1.box.value.name)
print(container2.box.value.name)
box.value.name = "Not Taylor"
print(container1.box.value.name)
print(container2.box.value.name)


//var arr1: NSArray = [taylor]
var arr2: NSArray = [box]

arr2[0]


// Wrapping is putting a class in a Struct to give it value semantics.
// You can then implement copy on write using
// isUniquelyReferenced(ptr)
// isUniquelyReferencedNonObjC(ptr)

// Mike Ash - Let's Build Swift Array
// https://www.mikeash.com/pyblog/friday-qa-2015-04-17-lets-build-swiftarray.html

// Next Week: Functions
// Variadic functions 
// Operator overloading 
// Closures
// The ~= operator

//: [Next](@next)
