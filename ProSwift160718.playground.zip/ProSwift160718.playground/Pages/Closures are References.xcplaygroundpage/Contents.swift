import Cocoa

// Value Types: booleans, numbers, strings, arrays, dictionaries, structs
// Reference Types: classes and closures

func createIncrementer() -> () -> Void {
	var counter = 0
	return {
		counter += 1
		print(counter)
	}
}

let incrementer = createIncrementer()
incrementer()
incrementer()

let incrementerCopy = incrementer
incrementerCopy()
incrementer()

// Value types
// inherently thread-safe
// avoid race conditions
// easier to reeason about your code
// - fewer relationships
// memberwise initializer provided

struct Person {
	var name: String
	var age: Int
	var favoriteIceCream: String
}

var swift = Person(name: "Taylor Swift", age: 26, favoriteIceCream:
	"Chocolate")

var tom = swift
tom.name = "Tom Swift"

swift.name
tom.name




// Classes
// performance - save all that time for copies
// inheritance
// Cocoa or Cocoa Touch require them
// make use of the power of NSObject and its protocols such as NSCoding and NSCopying
// Declaring a class to be final
// SE-0117 - Classes now default to be non-subclassable publicly   
// https://github.com/apple/swift-evolution/blob/81f2e0802452ffb98c2a2b83410ef4229c0d6393/proposals/0117-non-public-subclassable-by-default.md

// Joel Spolsky, "The Duct Tape Programmer"
// http://www.joelonsoftware.com/items/2009/09/23.html
// "Joel on Software"
// https://www.amazon.com/Joel-Software-Occasionally-Developers-Designers/dp/1590593898

//: [Next](@next)
