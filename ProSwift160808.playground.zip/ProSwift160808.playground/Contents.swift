import Cocoa

// higher order functions

// 5 Characteristics of functional programming
// 1) first-class data types
// 2) higher-order functions
// 3) pure functions - no side effects
// 4) immutability 
// 5) reduce state


func lengthOfStrings(strings: [String]) -> [Int] {
	return strings.map() { $0.characters.count }
}


func lengthOfStrings2(strings: [String]) -> [Int] {
	var result = [Int]()
	for string in strings {
		result.append(string.characters.count)
	}
	return result
}

lengthOfStrings(["Alice", "Ed", "Tiffany"])
lengthOfStrings2(["Alice", "Ed", "Tiffany"])

let fruits = ["Apple", "Cherry", "Orange", "Pineapple"]
let upperFruits = fruits.map { $0.uppercaseString }
upperFruits


let scores = [100, 80, 85]
let passOrFail = scores.map { $0 > 85 ? "Pass" : "Fail" }
passOrFail


let numbers: [Double] = [4, 9, 25, 36, 49]
let result = numbers.map(sqrt)


let i: Int? = nil
let j = i.map { $0 * 2 }
print(j)


func fetchUsername(id: Int) -> String? {
	if id == 1989 {
		return "Taylor Swift"
	}
	else {
		return nil
	}
}

var username: String? = fetchUsername(1989)
let formattedUsername = username.map { "Welcome, \($0)!" } ?? "Unknown user"
print(formattedUsername)


["Taylor", "Paul", "Adele"].forEach { print($0) }


let numbers2 = [[1, 2], [3, 4], [5, 6]]
let flattened = numbers2.flatten()
let flattened2 = Array(numbers2.flatten())
let flatten3 = numbers2.flatMap() { $0 }
flatten3

let albums: [String?] = ["Fearless", nil, "Speak Now", nil, "Red"]
let result2 = albums.flatMap { $0 }
print(result2)



let scores2 = ["100", "90", "Fish", "85"]
let flatMapScores = scores2.flatMap { Int($0) }
print(flatMapScores)


// let files = (1...10).flatMap { try? String(contentsOfFile: "someFile-\($0).txt") }
// print(files)


let fibonacciNumbers = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]
let evenFibonacci = fibonacciNumbers.filter { $0 % 2 == 0 }
evenFibonacci


let names = ["Michael Jackson", "Taylor Swift", "Michael Caine",
             "Adele Adkins", "Michael Jordan"]
let result3 = names.filter { $0.hasPrefix("Michael") }
result3


let words = ["1989", "Fearless", "Red"]
let input = "My favorite album is Fearless"
let result4 = words.filter(input.containsString)
result4



let words2: [String?] = ["1989", nil, "Fearless", nil, "Red"]
let result5 = words2.filter { $0 != nil }
print(result5)


let scores3 = ["Paul": 100, "Taylor": 95, "Adele": 90, "Michael": 85,
              "Justin": 60]
let gradedScores = (scores3.filter { $1 > 85 }).map { return ($0.0, "Pass") }
gradedScores



let scores4 = [100, 90, 95]
let result6 = scores.reduce(0, combine: +)


let result7 = words.reduce("") { $0 + $1 + " " }
result7

print(scores4.reduce([String]()) { $0 + [String($1)] })


let names2 = ["Taylor", "Paul", "Adele"]
print(names2.reduce(0) { $0 + $1.characters.count } )



let scoresString = ["100", "95", "85", "90", "100"]
let sortedString = scoresString.sort()
print(sortedString)

let sortedString2 = scoresString.sort() {$0 > $1}
print(sortedString2)

let sortedString3 = scoresString.sort().reverse()
print(sortedString2)

let sortedInt = ((scoresString.flatMap { Int($0) }).sort())     // no optional w/ flatmap
print(sortedInt)


let sortedInt2 = (scoresString.flatMap { Int($0) }).sort() {$0 > $1}
print(sortedInt2)



struct Person: Comparable {
	var name: String
	var age: Int
}

func <(lhs: Person, rhs: Person) -> Bool {
	return lhs.name < rhs.name
}

func ==(lhs: Person, rhs: Person) -> Bool {
	return lhs.name == rhs.name && lhs.age == rhs.age
}

let taylor = Person(name: "Taylor", age: 26)
let paul = Person(name: "Paul", age: 36)
let justin = Person(name: "Justin", age: 22)
let adele = Person(name: "Adele", age: 27)
let people = [taylor, paul, justin, adele]

people.sort()



func A() -> String {
	return "A"
}

func B(a: String) -> String {
	return a + "B"
}

func C(b: String) -> String {
	return b + "C"
}

let str = C(B(A()))



func generateRandomNumber(max: Int) -> Int {
	let number = Int(arc4random_uniform(UInt32(max)))
	print("Using number: \(number)")
	return number
}

func calculateFactors(number: Int) -> [Int] {
	return (1...number).filter { number % $0 == 0 }
}

func reduceToString(numbers: [Int]) -> String {
	return numbers.reduce("Factors: ") { $0 + String($1) + " " }
}

let result8 = reduceToString(calculateFactors(generateRandomNumber(100)))
print(result8)


let nums = 1...10000
let lazyFilter = nums.lazy.filter { $0 % 2 == 0 }
let lazyMap = nums.lazy.map { $0 * 2 }

//print(lazyFilter.count)
//print(lazyFilter.count)
//print(lazyMap[5000])
//print(lazyMap[5000])



//  A functor is a container that implements map(). It doesn't need to be called map(), but it does need to do the same thing: convert A into B by applying a transformation. We've been using lots of arrays and optionals, both of which are functors. map() is not the functor – array is the functor, because it implements map().

//  A monad is a functor that also implements flatMap(). Again, arrays and optionals are monads. The formal definition for monads in Haskell – commonly seen as the definitive reference – adds a few other rules, but when you're working with Swift just think about flatMap() and you're there.

//  So: a functor is a data type that can be mapped over, and a monad is a functor that also can be flatmapped over.
