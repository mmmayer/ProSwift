//: [Previous](@previous)

import Foundation

let scoresString = ["100", "95", "85", "90", "100"]
let sortedString = scoresString.sort()
print(sortedString)

let sortedString2 = scoresString.sort() {$0 > $1}
print(sortedString2)

let sortedString3 = scoresString.sort().reverse()
print(sortedString2)

let sortedInt = ((scoresString.flatMap { Int($0) }).sort())     // no optional w/ flatmap
print(sortedInt)


let sortedInt2 = (scoresString.flatMap { Int($0) }).sort() {$0 > $1}
print(sortedInt2)

let sortedInt3 = Array(((scoresString.flatMap { Int($0) }).sort()).reverse())     // no optional w/ flatmap
print(sortedInt3)



struct Person: Comparable {
	var name: String
	var age: Int
}

func <(lhs: Person, rhs: Person) -> Bool {
	return lhs.name < rhs.name
}

func ==(lhs: Person, rhs: Person) -> Bool {
	return lhs.name == rhs.name && lhs.age == rhs.age
}

let taylor = Person(name: "Taylor", age: 26)
let paul = Person(name: "Paul", age: 36)
let justin = Person(name: "Justin", age: 22)
let adele = Person(name: "Adele", age: 27)
let people = [taylor, paul, justin, adele]

people.sort()



func A() -> String {
	return "A"
}

func B(a: String) -> String {
	return a + "B"
}

func C(b: String) -> String {
	return b + "C"
}

let str = C(B(A()))



func generateRandomNumber(max: Int) -> Int {
	let number = Int(arc4random_uniform(UInt32(max)))
	print("Using number: \(number)")
	return number
}

func calculateFactors(number: Int) -> [Int] {
	return (1...number).filter { number % $0 == 0 }
}

func reduceToString(numbers: [Int]) -> String {
	return numbers.reduce("Factors: ") { $0 + String($1) + " " }
}

let result8 = reduceToString(calculateFactors(generateRandomNumber(100)))
print(result8)


let nums = 1...10000
let lazyFilter = nums.lazy.filter { $0 % 2 == 0 }
let lazyMap = nums.lazy.map { $0 * 2 }

print(lazyFilter.count)
print(lazyFilter.count)
print(lazyMap[5000])
print(lazyMap[5000])



//  A functor is a container that implements map(). It doesn't need to be called map(), but it does need to do the same thing: convert A into B by applying a transformation. We've been using lots of arrays and optionals, both of which are functors. map() is not the functor – array is the functor, because it implements map().

//  A monad is a functor that also implements flatMap(). Again, arrays and optionals are monads. The formal definition for monads in Haskell – commonly seen as the definitive reference – adds a few other rules, but when you're working with Swift just think about flatMap() and you're there.

//  So: a functor is a data type that can be mapped over, and a monad is a functor that also can be flatmapped over.


//: [Next](@next)
