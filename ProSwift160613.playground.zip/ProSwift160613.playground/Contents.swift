import Cocoa

let authentication = (name: "twostraws", password: "fr0st1es")

switch authentication {
case ("bilbo", _):
	print("Hello, Bilbo Baggins!")
case ("twostraws", authentication.password):
	print("Hello, Paul Hudson: your password was \(authentication.password)!")
default:
	print("Who are you?")
}

///=============
func fizzbuzz(number number: Int) -> String {
	switch (number % 3, number % 5) {
	case (0, 0):
		return "FizzBuzz"
	case (0, _):
		return "Fizz"
	case (_, 0):
		return "Buzz"
	case (_, _):
		return String(number)
	}
}

print(fizzbuzz(number: 15))

///=============
let twostraws = (name: "twostraws", password: "fr0st1es")
let bilbo = (name: "bilbo", password: "bagg1n5")
let taylor = (name: "taylor", password: "fr0st1es")
let users = [twostraws, bilbo, taylor]

for case let (name, "fr0st1es") in users {
	print("User \(name) has the password \"fr0st1es\"")
}

///=============
let name: String? = "twostraws"
let password: String? = "fr0st1es"

switch (name, password) {
case (.Some, .Some):
	print("Hello, \(name!)")
case let (username?, nil):
	print("Please enter a password.")
default:
	print("Who are you?")
}

let data: [AnyObject?] = ["Bill", nil, 69, "Ted"]
for case let .Some(datum) in data {
	print(datum)
}

///=============
let age = 18
if  0 ... 18 ~= age {
	print("You have the energy and time, but not the money")
} else if 19 ..< 70 ~= age {
	print("You have the energy and money, but not the time")
} else {
	print("You have the time and money, but not the energy")
}

///=============
enum WeatherType {
	case Cloudy(coverage: Int)
	case Sunny
	case Windy
}

let forecast: [WeatherType] = [.Cloudy(coverage: 40), .Sunny, .Windy, .Cloudy(coverage: 100), .Sunny]

for case let .Cloudy(coverage) in forecast {
	print(coverage)
}

///=============
let today = WeatherType.Cloudy(coverage: 100)

switch today {
case .Cloudy(0):
	print("You must live in Death Valley")
case .Cloudy(100):
	print("You must live in the UK")
case .Cloudy(let coverage):
	print("It's cloudy with \(coverage)% coverage")
case .Windy:
	print("It's windy")
default:
	print("It's sunny")
}

///=============
let view: AnyObject = NSMatrix()
switch view {
case is NSButton:
	print("Found a button")
case is NSTextField:
	print("Found a field")
case is NSPopover:
	print("Found a popover")
case is NSView:
	print("Found a view")
default:
	print("Found something else")
}

///=============
let myName: String? = "Taylor"
let unwrappedName = myName ?? "Anonymous"
print(unwrappedName)
print(myName ?? "Anonymous")

let nakedName = myName != nil ? myName! : "Anonymous"

///=============
let savedText: String
do {
	savedText = try String(contentsOfFile: "saved.txt")
} catch {
	print("Failed to load saved text.")
	savedText = "Hello, world!"
}
print(savedText)

let moreSavedText = (try? String(contentsOfFile: "saved.txt")) ?? "Hello, world!"
print(moreSavedText)

///=============
func giveAwardTo(name: String) {
	guard name == "Taylor Swift" else {
		print("No way!")
		return
	}
	print("Congratulations, \(name)!")
}
giveAwardTo("Taylor Swift")

///=============
func giveAwardThisYear(name: String?) {
	guard let winner = name else {
		print("No one won the award")
		return
	}
	print("Congratulations, \(winner)!")
	// Notice that "winner" is also available outside the guard statement
	// This is different than an "if let"  where the binding is only 
	// available inside the body of the "if" statement
}
giveAwardThisYear("Taylor")
giveAwardThisYear(nil)

///=============
for i in 1...100 {
	guard i % 11 == 0 else { continue }
	print(i)
}
