//: [Previous](@previous)

import Foundation

// Problem 6
//Extend Array and create a method that returns true if two arrays contain the same
//elements, regardless of their order.  Probably need two constraints here.

extension CollectionType where Generator.Element: Comparable {
	func fuzzyMatch(other: Self) -> Bool {
		let usSorted = sort()
		let otherSorted = other.sort()
		
		return usSorted == otherSorted
	}
}


//: [Next](@next)
