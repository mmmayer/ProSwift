//: [Previous](@previous)

import Foundation

// Problem 6
//Extend Array and create a method that returns true if two arrays contain the same
//elements, regardless of their order.  Probably need two constraints here.


//: [Next](@next)
