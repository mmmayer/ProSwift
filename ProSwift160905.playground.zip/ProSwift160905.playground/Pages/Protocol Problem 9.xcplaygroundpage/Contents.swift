//: [Previous](@previous)

import Foundation

//NINTH EXAMPLE

//You can also do the opposite: extend a fixed collection type where its
//elements conform to a particular protocol. For example, we could
//create a method that de-dupes an array:

extension Array where Element: Hashable {
	func uniqueValues() -> [Element] {
		var result = [Element]()
		
		for item in self {
			if !result.contains(item) {
				result.append(item)
			}
		}
		
		return result
	}
}


//: [Next](@next)
