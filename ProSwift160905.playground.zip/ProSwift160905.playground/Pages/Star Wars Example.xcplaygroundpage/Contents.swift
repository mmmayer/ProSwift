//: [Previous](@previous)

import Foundation

// We’re going to model a Star Wars battle using structs, protocol, and protocol extensions.  This demonstrates the two-step process: create the protocol then create the extension.

protocol Targetable {
	func takeDamage()
}
extension Targetable {
	func takeDamage() {
		print("I'm hit!")
	}
}

protocol Fireable {
	func shootAt(target: Targetable)
}
extension Fireable {
	func shootAt(target: Targetable) {
		print("I'm firing!")
		target.takeDamage()
	}
}

protocol Ejectable {
	func eject()
}
extension Ejectable {
	func eject() {
		print("I ejected")
	}
}

// We’re going to make two structs: one for X-Wings and one for the Death Star.
// Because we used protocol extensions to provide a default implementation, we 
// don't need to implement each method several times

struct XWing: Fireable, Targetable, Ejectable {
}

struct DeathStar: Fireable, Targetable {
}





// let’s start using our structs:

let luke = XWing()
let deathStar = DeathStar()

luke.shootAt(deathStar)
deathStar.shootAt(luke)

//It doesn’t matter that they are both different data types: they both
//conform to Targetable and Fireable so they can both fire at each
//other.

//Let’s add another struct now:

struct TIEFighter: Fireable, Targetable, Ejectable {
}

//Having all three protocols duplicated for XWing and TIEFighter is
//likely to cause problems if you continue to add new structs, so we can
//group them together:

protocol Fighter: Fireable, Targetable, Ejectable { }

struct XWing2: Fighter {
}

struct TIEFighter2: Fighter {
}

//The extensions we created are default implementations of methds, but
//you can implement custom version in individual structs that need it.
//For example:

extension XWing2 {
	func eject() {
		print("Eject? I'd rather crash into the Death Star!")
	}
}

extension TIEFighter2 {
	func eject() {
		print("I'm totes out of here.")
	}
}

//POP uses polymorphism just like OOP, so we can create an array of
//XWing and TIEFighter instances then ask them to eject – Swift will
//ensure the correct method is called:

let fighters: [Fighter] = [XWing2(), XWing2(), TIEFighter2()]

for fighter in fighters {
	fighter.eject()
}

//Note that we need to be specific about the data type of the array –
//Swift doesn’t know whether it should be an array of Targetable,
//Ejectable, etc.

//: [Next](@next)
