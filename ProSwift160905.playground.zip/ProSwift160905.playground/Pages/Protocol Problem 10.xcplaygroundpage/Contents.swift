//: [Previous](@previous)

import Foundation

// Extend Array and write a method that returns true if an array is sorted.

extension Array where Element: Comparable {
	func isSorted() -> Bool {
		let sorted = sort()
		return sorted == self
	}
}
//: [Next](@next)
