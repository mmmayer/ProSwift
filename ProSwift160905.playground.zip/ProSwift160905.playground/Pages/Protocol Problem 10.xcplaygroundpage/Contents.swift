//: [Previous](@previous)

import Foundation

// Extend Array and write a method that returns true if an array is sorted.

//: [Next](@next)
