//: [Previous](@previous)

import Foundation

//Those last two examples extended protocols where their items also
//conformed to a protocol. We can also extend protocols where items are
//a specific data type by using == rather than :

//For example, this extends collections of strings

//extension CollectionType where Generator.Element == String

// Use this to write an extension to CollectionType that returns the average length of a collection of Strings


//: [Next](@next)
