//: [Previous](@previous)

import Foundation

// Problem 2
// Create an extension for all integer types
// that returns the value clamped between two values.


extension IntegerType {
	func clamp(minimum: Self, maximum: Self) -> Self {
		return max(minimum, min(maximum, self))
	}
}
//: [Next](@next)
