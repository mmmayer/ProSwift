//: [Previous](@previous)

import Foundation

// Problem 2
// Create an extension for all integer types
// that returns the value clamped between two values.




//: [Next](@next)
