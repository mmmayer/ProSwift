//: [Previous](@previous)

import Foundation

// Problem 3
// Next we’re going to add an extension to the Equatable protocol.
// Everything that conforms to this protocol can be checked for equality
// with another item of the same type.

// Add an extension to Equatable to create a method so that an equatable value can be
// checked against all other values in an array, returning a boolean.

extension Equatable {
	func myContains(arr: Array<Self>)-> Bool {
		for elem in arr {
			if elem == self {
				return true
			}
		}
		return false
	}
}

let a: Double = 8
a.myContains([5, 6.5, 7, 8, 9])


//: [Next](@next)
