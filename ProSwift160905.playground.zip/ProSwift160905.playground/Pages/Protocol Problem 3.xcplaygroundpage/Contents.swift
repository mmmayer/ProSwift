//: [Previous](@previous)

import Foundation

// Problem 3
// Next we’re going to add an extension to the Equatable protocol.
// Everything that conforms to this protocol can be checked for equality
// with another item of the same type.

// Add an extension to Equatable to create a method so that an equatable value can be
// checked against all other values in an array, returning a boolean.

//: [Next](@next)
