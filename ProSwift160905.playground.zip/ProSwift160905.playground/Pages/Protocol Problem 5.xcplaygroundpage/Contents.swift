//: [Previous](@previous)

import Foundation

func ==(lhs: Person, rhs: Person) -> Bool {
	return true
}

// Problem 5
// Extend CollectionType and recreate the contains() method.  You'll definately need a constraint on this one.

extension CollectionType where Generator.Element: Equatable {
	func myContains(element: Generator.Element) -> Bool {
		for item in self {
			if item == element {
				return true
			}
		}
		return false
	}
}
struct Person {
	var name: String
	var age: Int
}

extension Person: Equatable {}


let people = [Person(name: "Bob", age: 4), Person(name: "Alice", age: 23)]
let nums = [4, 5, 6, 7]


//: [Next](@next)
