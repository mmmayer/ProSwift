//: [Previous](@previous)

import Foundation

// Problem 5
// Extend CollectionType and recreate the contains() method.  You'll definately need a constraint on this one.




//: [Next](@next)
