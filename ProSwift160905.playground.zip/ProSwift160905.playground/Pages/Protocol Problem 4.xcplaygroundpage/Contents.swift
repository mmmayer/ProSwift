//: [Previous](@previous)

import Foundation

//Problem 4
//Extend a protocol with a method that returns true if a number is less than all other numbers in an array, e.g. 9.lessThanArray(array).  You may need a constraint or possiblly an associated type.

extension Comparable {
	func lessThanArray(items: [Self]) -> Bool {
		for item in items {
			if item >= self {
				return false
			}
		}
		return true
	}
}


let a = 8.1
a.lessThanArray([1, 2.2, 3, 4])

//: [Next](@next)
