//: [Previous](@previous)

import Foundation

//Problem 4
//Extend a protocol with a method that returns true if a number is less than all other numbers in an array, e.g. 9.lessThanArray(array).  You may need a constraint or possiblly an associated type.


//: [Next](@next)
