//: [Previous](@previous)

import Foundation

// PROTOCOL ASSOCIATED TYPES

// Let’s model a singer and some songs.

protocol Song { }
struct CountrySong: Song { }

protocol Singer {
	func sing(s: Song)
}

struct CountrySinger: Singer {
	func sing(s: Song) { }
}

//That’s all OK. But what if we want to make the CountrySinger sing
//CountrySongs? You can’t: this breaks.

func sing(s: CountrySong) { }

//Why? Because of subtyping rules: you can’t force a more specific type
//on a child type, because it might be used generically – i.e., an array
//of Singers might be asked to sing general songs, and you’re trying to
//force one to sing only country songs.

//Associated types give us a solution, but it’s usually confusing at
//first, and it has its own set of problems.

//We can rewrite our example to this:

struct Song2 { }
struct CountrySong2 { }

protocol Singer2 {
	associatedtype SongType
	func sing(s: SongType)
}

//The associatedtype keyword means “this protocol is incomplete; it has
//a huge hole in it that must be filled by whatever implements the
//protocol.” Everything that adopts this protocol must fill that hole.

//So when we want to write the CountrySinger struct, we fill in the hole:

struct CountrySinger2: Singer2 {
	typealias SongType = CountrySong
	func sing(s: SongType) { }
}

//Inside the sing() method for CountrySinger, we have a CountrySong
//instance, so methods are called there rather than on Song.

//We can go ahead and use this:

let taylor = CountrySinger2()
let garth = CountrySinger2()
var singers = [taylor, garth]

//Great – we have an array of singers. Let’s make things more
//interesting by adding a new kind of singer:

struct OperaSong { }

struct OperaSinger: Singer2 {
	typealias SongType = OperaSong
	func sing(s: SongType) { }
}

let luciano = OperaSinger()

//We want to put that into our array of singers, so we could try doing this:
// Uncomment the following line to see error:

//singers.append(luciano)

//But that won’t work. Swift considers the array to be an array of
//CountrySingers, not any kind of singers. Fortunately, both
//CountrySinger and OperaSinger come from the same type, so in theory
//all we have to do is modify the definition of singers…
// Uncomment the following line to see error:

//var singers2: [Singer2] = [taylor, garth]
//singers2.append(luciano)

//And now you have one of the most confusing error messages in all of Swift.
//Problem: the associated type can be literally anything, so the Swift
//compiler is unable to ensure type correctness.

//Think about it: we could have mode OperaSinger work like this:

typealias SongType = Int

//And that’s perfectly legal. It makes no sense to have an array of a PAT (Protocols with Associated Types).

//This same problem affects you when you have Self requirements. This is
//a special keyword you can use in protocols that acts as a placeholder
//for whatever type conforms to the protocol.

//For example, we could define this:

protocol Singer3 {
	func singDuetWith(singer: Self)
}

struct CountrySinger3: Singer3 {
	func singDuetWith(singer: CountrySinger3) {
		print("Haters gonna hate")
	}
}

struct OperaSinger2: Singer3 {
	func singDuetWith(singer: OperaSinger2) {
		print("La donna è mobile")
	}
}

//However, that still suffers from the same problem: you can’t make
//arrays out of them.

//The error message says it can only be used as a generic constraint,
//which means it’s limited to being used by generics, like this:

struct Band<T: Singer> {
	var lead: T
	var backup: T
}

//Why? Because it’s still type-safe.


//: [Next](@next)
