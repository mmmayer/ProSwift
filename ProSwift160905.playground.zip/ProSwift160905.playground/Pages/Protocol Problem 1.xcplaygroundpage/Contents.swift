//: Pro Swift - Bonus Material

import Cocoa

//Problem 1
//Part 1: Let’s start by creating an extension for the Int type that will
//calculate the value squared.




//Because you extended the Int type, that extension won’t be visible to
//other similar data types. For example, this won’t compile:
//
// let j: UInt = 8
// print(j.squared())
//
//Part 2: To make that work, create an extension to extend the IntegerType protocol, which will affect all types of integer – Int, UInt, Int64, etc




//: [Next](@next)
