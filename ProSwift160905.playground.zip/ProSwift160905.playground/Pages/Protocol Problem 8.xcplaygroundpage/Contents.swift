//: [Previous](@previous)

import Foundation

EIGHTH EXAMPLE

//Create an extension that accepts an array of integers, and returns the
//how many times the number 5 appears in any number, e.g. 5, 15, 55, 555
//should return 7.


//: [Next](@next)
