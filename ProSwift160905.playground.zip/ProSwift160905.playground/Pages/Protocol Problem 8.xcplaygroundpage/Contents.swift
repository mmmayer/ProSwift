//: [Previous](@previous)

import Foundation

//EIGHTH Problem

//Create an extension that accepts an array of integers, and returns the
//how many times the number 5 appears in any number, e.g. 5, 15, 55, 555
//should return 7.

extension CollectionType where Generator.Element == Int {
	func numberOf5s() -> Int {
		var count = 0
		
		for item in self {
			let str = String(item)
			
			for letter in str.characters {
				if letter == "5" {
					count += 1
				}
			}
		}
		return count
	}
}



//: [Next](@next)
