//: [Previous](@previous)

import Foundation

//func mid<T>(array: [T]) -> T {
//	return array.sort()[(array.count - 1) / 2]
//}

func median<T where T: Comparable>(array: [T]) -> T {
	return array.sort()[(array.count - 1) / 2]
}

let a = median([4, 5, 7, 2, 1, -3, 17])
let b = median([4.1, 5.7, 7.3, 2.2, 1.5, -3.0, 17.1])
let c = median(["zach", "bob", "alice", "eugene", "phil", "tracey", "michael"])


func adder<T: Summable>(x: T, _ y: T) -> T {
	return x + y
}

protocol Summable {
	func +(lhs: Self, rhs: Self) -> Self
}

extension Int: Summable {}
extension Double: Summable {}
extension String: Summable {}

let adderIntSum = adder(1, 2)
let adderDoubleSum = adder(1.0, 2.0)
let adderString = adder("Generics", " are Awesome!!! :]")

//: [Previous](@previous)


