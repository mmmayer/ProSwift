// Pro Swift - Generics
// WWDC 2016 Video 416: Understanding Swift Performance

import Cocoa

func adderInt(x: Int, _ y: Int) -> Int {
	return x + y
}

let intSum = adderInt(1, 2)

func adderDouble(x: Double, _ y: Double) -> Double {
	return x + y
}

let doubleSum = adderDouble(1.0, 2.0)


let numbers = [1, 2, 3]

let firstNumber = numbers[0]

var numbersAgain = Array<Int>()
numbersAgain.append(1)
numbersAgain.append(2)
numbersAgain.append(3)

numbers == numbersAgain

let firstNumberAgain = numbersAgain[0]

let countryCodes = ["Austria": "AT", "United States of America": "US", "Turkey": "TR"]

let at = countryCodes["Austria"]

let optionalName: String? = Optional<String>.Some("John")

if let name = optionalName {
	
	
}

func pairsFromDictionary<KeyType, ValueType>(dictionary: [KeyType: ValueType]) -> [(KeyType, ValueType)] {
	return Array(dictionary)
}

struct myType {
	
}

let a = myType()
let b = myType()

let pairs = pairsFromDictionary([2.0: 199, 3.0: 299])
let morePairs = pairsFromDictionary([1: "Swift", 2: "Generics", 3: "Rule"])


//: [Next](@next)
