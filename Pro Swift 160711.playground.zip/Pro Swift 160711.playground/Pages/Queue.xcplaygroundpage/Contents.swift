//: [Previous](@previous)

import Cocoa

struct Queue<Element> {
	private var elements = [Element]()
	
	mutating func enqueue(newElement: Element) {
		elements.append(newElement)
	}
 
	mutating func dequeue() -> Element? {
		guard !elements.isEmpty else { return nil }
		return elements.removeAtIndex(0)
	}
}

var q = Queue<Int>()

q.enqueue(4)
q.enqueue(2)

q.dequeue()
q.dequeue()
q.dequeue()
q.dequeue()



//: [Next](@next)



extension Queue {
	func peek() -> Element? {
		return elements.first
	}
}


q.enqueue(5)
q.enqueue(3)
q.peek()
q

extension NSViewController : NSTextFieldDelegate {
	
	
}

extension NSViewController : NSCollectionViewDelegate {
	
	
}


extension Queue where Element : Comparable {
	func allSame() -> Bool? {
		guard !elements.isEmpty else { return nil }
		let sample = elements[0]
		for elem in elements {
			if elem != sample {
				return false
			}
		}
		return true
	}
}

q.allSame()
q.dequeue()
q.allSame()
q.enqueue(3)
q.allSame()
q.dequeue()
q.dequeue()
q.dequeue()
q.dequeue()
var e = q.allSame()

struct mine {
	
}

let r = mine()
let s = mine()

var p = Queue<mine>()
p.enqueue(r)
p.enqueue(s)

//p.allSame()   // errors because p doesn't contain elements that are comparable.  allSame() is limited
			  //to just queues that contain elements that are comparable


