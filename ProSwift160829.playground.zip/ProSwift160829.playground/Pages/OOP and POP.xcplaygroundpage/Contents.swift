//: ProSwift - Chapter 7

import Cocoa

extension Int {
	// iterates the closure body a specified number of times
	func times(closure: (Int) -> Void) {
		for i in 1...self {
			closure(i)
		}
	}
}

10.times {x in  print(x, "A") }


protocol Payable {
	func calculateWages() -> Int
}

extension Payable {
	func calculateWages() -> Int {
		return 10000
	}
}

struct Surgeon { }
extension Surgeon: Payable {
	func calculateWages() -> Int {
		return 20000
	}
}

let gregory = Surgeon()
gregory.calculateWages()
let doogie : Payable = Surgeon()
doogie.calculateWages()


//: [Next](@next)
