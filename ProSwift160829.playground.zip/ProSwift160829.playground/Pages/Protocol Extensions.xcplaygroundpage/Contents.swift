//: [Previous](@previous)

import Foundation

struct Receptionist { }
struct Nurse { }
struct Doctor { }
struct Surgeon { }

protocol Payable {
	func calculateWages() -> Int
}

extension Payable {
	func calculateWages() -> Int {
		return 10000
	}
}

protocol ProvidesTreatment {
	func treat(name: String)
}

extension ProvidesTreatment {
	func treat(name: String) {
		print("I have treated \(name)")
	}
}

protocol ProvidesDiagnosis {
	func diagnose() -> String
}

extension ProvidesDiagnosis {
	func diagnose() -> String {
		return "He's dead, Jim"
	}
}

protocol ConductsSurgery {
	func performSurgery()
}

extension ConductsSurgery {
	func performSurgery() {
		print("Success!")
	}
}

protocol HasRestTime {
	func takeBreak()
}

extension HasRestTime {
	func takeBreak() {
		print("Time to watch TV")
	}
}

protocol NeedsTraining {
	func study()
}

extension NeedsTraining {
	func study() {
		print("I'm reading a book")
	}
}

protocol Employee: Payable, HasRestTime, NeedsTraining {}

extension Receptionist: Employee {}
extension Nurse: Employee, ProvidesTreatment {}
extension Doctor: Employee, ProvidesDiagnosis, ProvidesTreatment {}
extension Surgeon: Employee, ProvidesDiagnosis, ConductsSurgery {}



extension CollectionType where Generator.Element: IntegerType {
	func countOddEven() -> (odd: Int, even: Int) {
		var even = 0
		var odd = 0
		
		for val in self {
			if val % 2 == 0 {
				even += 1
			} else {
				odd += 1
			}
		}
		return (odd: odd, even: even)
	}
}

var a = Array<Int32>()
a = [1,2,3,4]
print(a.countOddEven())

//: [Next](@next)
