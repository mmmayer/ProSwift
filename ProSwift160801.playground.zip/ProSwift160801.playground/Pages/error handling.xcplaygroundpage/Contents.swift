//: [Previous](@previous)

import Foundation


enum PasswordError: ErrorType {
	case Empty
	case Short(minChars: Int)
	case Obvious(message: String)
}

func encryptString(str: String, withPassword password: String) throws -> String {
	// complicated encryption goes here
	
	if password == "12345" {
		throw PasswordError.Obvious(message: "I have the same number on my luggage")
	}
	if password.characters.count < 8 {
		throw PasswordError.Short(minChars:password.characters.count)
	}
	let encrypted = password + str + password
	return String(encrypted.characters.reverse())
	
}

func testCatch() {
	do {
		let encrypted = try encryptString("secret information!", withPassword: "T4yl0r")
		print(encrypted)
		
	} catch PasswordError.Short(let minChars) where minChars < 5 {
		print("We have a lax security policy: passwords must be at least \(minChars)")
	} catch PasswordError.Short(let minChars) where minChars < 8 {
		print("We have a moderate security policy: passwords must be at least \(minChars)")
	} catch PasswordError.Short(let minChars) {
		print("We have a serious security policy: passwords must be at least \(minChars)")
	} catch PasswordError.Obvious(let msg) {
		print("Silly password: \(msg)")
	} catch {
		print("Error")
	}
}

testCatch()



//: [Next](@next)
