//: [Previous](@previous)

import Foundation

enum PasswordError: ErrorType {
	case Empty
	case Short
	case Obvious
}

func functionA() {
	do {
		try functionB()
	} catch {
		print("Error!")
	}
}

func functionB() throws {
	do {
		try functionC()
	} catch PasswordError.Empty {
		print("Empty password!")
	}
}

func functionC() throws {
	throw PasswordError.Short
}

functionA()




func definitelyWontThrow() {
	print("Shiny!")
}

/// try definitelyWontThrow()


enum Failure: ErrorType {
	case BadNetwork(message: String)
	case Broken
}

func fetchRemote() throws -> String {
	// complicated, failable work here
	throw Failure.BadNetwork(message: "Firewall blocked port.")
}

func fetchLocal() -> String {
	// this won't throw
	return "Taylor"
}


func fetchUserData(closure: () throws -> String) {
	do {
		let userData = try closure()
		print("User data received: \(userData)")
	} catch Failure.BadNetwork(let message) {
		print(message)
	} catch {
		print("Fetch error")
	}
}

fetchUserData(fetchRemote)   // fetchRemote


func fetchUserData2(closure: () throws -> String) rethrows {
	let userData = try closure()
	print("User data received: \(userData)")
}

do {
	try fetchUserData2(fetchLocal)
} catch Failure.BadNetwork(let message) {
	print(message)
} catch {
	print("Fetch error")
}



/* 

try: When using try you must have a catch block to handle any errors that occur.

try?: When using try? the function you call will automatically return nil if any errors are thrown. You don't need to catch them, but you do need to be aware that your return value becomes optional.

try!: When using try! the function will crash your application if any errors are thrown.

*/



//: [Next](@next)
