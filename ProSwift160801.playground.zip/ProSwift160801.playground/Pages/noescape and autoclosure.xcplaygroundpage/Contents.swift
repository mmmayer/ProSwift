import Cocoa

var queuedClosures: [() -> Void] = []

func queueClosure(closure: () -> Void) {   // @noescape
	queuedClosures.append(closure)
}

queueClosure({ print("Running closure 1") })
queueClosure({ print("Running closure 2") })
queueClosure({ print("Running closure 3") })

func executeQueuedClosures() {
	for closure in queuedClosures {
		closure()
	}
}

executeQueuedClosures()



func printTest(result: () -> Void) {  // @autoclosure
	print("Before")
	result()
	print("After")
}

printTest( { print("Hello") } )

assert(1 == 1 , "Maths failure!")



// @autoclosure(escaping)



//: [Next](@next)
