//: [Previous](@previous)

import Foundation

// assert( 1 == 2 )
// assert(1 == 2, "End of the World as we know it")

// precondition( 1 == 2 )
// precondition(1 == 2, "End of the World as we know it 2")

// -Ounchecked


//: [Next](@next)
